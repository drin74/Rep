import csv
import sqlite3
from datetime import date, datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk

APP_DIR = Path.home() / ".buh_calculator"
APP_DIR.mkdir(exist_ok=True)
DB_PATH = APP_DIR / "buh_calculator.db"
SETTINGS_PATH = APP_DIR / "settings.json"

ACCENTS = {
    "Синий": "#3478F6",
    "Изумрудный": "#10A37F",
    "Фиолетовый": "#8B5CF6",
    "Оранжевый": "#E58B25",
    "Розовый": "#DB4B83",
}

def money(value):
    return f"{value:,.2f}".replace(",", " ").replace(".", ",")

class Database:
    def __init__(self):
        with sqlite3.connect(DB_PATH) as con:
            con.execute("""CREATE TABLE IF NOT EXISTS entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_date TEXT NOT NULL,
                kind TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT,
                amount REAL NOT NULL,
                vat_rate REAL NOT NULL DEFAULT 0
            )""")

    def add(self, entry_date, kind, category, description, amount, vat_rate):
        with sqlite3.connect(DB_PATH) as con:
            con.execute("INSERT INTO entries(entry_date,kind,category,description,amount,vat_rate) VALUES(?,?,?,?,?,?)",
                        (entry_date, kind, category, description, amount, vat_rate))

    def all(self, start=None, end=None):
        sql = "SELECT id, entry_date, kind, category, description, amount, vat_rate FROM entries"
        args = []
        if start and end:
            sql += " WHERE entry_date BETWEEN ? AND ?"
            args = [start, end]
        sql += " ORDER BY entry_date DESC, id DESC"
        with sqlite3.connect(DB_PATH) as con:
            return con.execute(sql, args).fetchall()

    def delete(self, entry_id):
        with sqlite3.connect(DB_PATH) as con:
            con.execute("DELETE FROM entries WHERE id=?", (entry_id,))

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("БухКальк — бухгалтерский калькулятор")
        self.geometry("1180x760")
        self.minsize(980, 650)
        self.db = Database()
        self.settings = self.load_settings()
        ctk.set_appearance_mode(self.settings.get("mode", "Dark"))
        ctk.set_default_color_theme("blue")
        self.accent = self.settings.get("accent", ACCENTS["Синий"])
        self.configure(fg_color=("gray95", "#10141D"))
        self.build_ui()
        self.refresh()

    def load_settings(self):
        try:
            return json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {"mode": "Dark", "accent": ACCENTS["Синий"]}

    def save_settings(self):
        SETTINGS_PATH.write_text(json.dumps(self.settings, ensure_ascii=False, indent=2), encoding="utf-8")

    def build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        side = ctk.CTkFrame(self, width=220, corner_radius=0, fg_color=("#E9EEF6", "#171D29"))
        side.grid(row=0, column=0, sticky="nsew")
        side.grid_rowconfigure(8, weight=1)
        ctk.CTkLabel(side, text="◈  БухКальк", font=ctk.CTkFont(size=24, weight="bold"),
                     text_color=self.accent).grid(row=0, column=0, padx=20, pady=(28, 4), sticky="w")
        ctk.CTkLabel(side, text="ФИНАНСЫ ПОД КОНТРОЛЕМ", font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=("gray45", "gray55")).grid(row=1, column=0, padx=22, pady=(0, 28), sticky="w")
        self.nav_buttons = {}
        for i, (key, label) in enumerate([("overview", "▦  Обзор"), ("entries", "⇄  Операции"),
                                          ("calculator", "∑  НДС-калькулятор"), ("usn", "₽  Расчёт УСН"),
                                          ("sick", "✚  Больничный"), ("maternity", "♡  Декретные"),
                                          ("vacation", "☼  Отпускные"), ("reports", "▤  Отчёты"),
                                          ("settings", "⚙  Дизайн")], start=2):
            b = ctk.CTkButton(side, text=label, anchor="w", height=43, corner_radius=10,
                              fg_color="transparent", hover_color=("#D8E3F5", "#252E40"),
                              text_color=("gray20", "gray85"), command=lambda k=key: self.show_page(k))
            b.grid(row=i, column=0, padx=12, pady=4, sticky="ew")
            self.nav_buttons[key] = b
        ctk.CTkLabel(side, text="Локальная база данных\nДанные хранятся на этом ПК",
                     font=ctk.CTkFont(size=11), text_color=("gray45", "gray55"),
                     justify="left").grid(row=9, column=0, padx=20, pady=22, sticky="sw")
        self.main = ctk.CTkFrame(self, fg_color="transparent")
        self.main.grid(row=0, column=1, sticky="nsew", padx=26, pady=24)
        self.main.grid_columnconfigure(0, weight=1)
        self.show_page("overview")

    def clear_main(self):
        for w in self.main.winfo_children():
            w.destroy()

    def header(self, title, subtitle):
        ctk.CTkLabel(self.main, text=title, font=ctk.CTkFont(size=28, weight="bold")).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(self.main, text=subtitle, font=ctk.CTkFont(size=13),
                     text_color=("gray45", "gray60")).grid(row=1, column=0, sticky="w", pady=(4, 22))

    def show_page(self, page):
        self.page = page
        self.clear_main()
        for k, b in self.nav_buttons.items():
            b.configure(fg_color=self.accent if k == page else "transparent",
                        text_color="white" if k == page else ("gray20", "gray85"))
        if page == "overview": self.page_overview()
        elif page == "entries": self.page_entries()
        elif page == "calculator": self.page_calculator()
        elif page == "usn": self.page_usn()
        elif page == "sick": self.page_sick()
        elif page == "maternity": self.page_maternity()
        elif page == "vacation": self.page_vacation()
        elif page == "reports": self.page_reports()
        elif page == "settings": self.page_settings()

    def summary(self, rows):
        income = sum(r[5] for r in rows if r[2] == "Доход")
        expense = sum(r[5] for r in rows if r[2] == "Расход")
        vat = sum(r[5] * r[6] / 100 for r in rows)
        return income, expense, income-expense, vat

    def stat_card(self, parent, title, value, color=None):
        card = ctk.CTkFrame(parent, corner_radius=16, border_width=1, border_color=("gray85", "#283244"))
        card.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(card, text=title, text_color=("gray45", "gray60"), font=ctk.CTkFont(size=12)).grid(row=0, column=0, sticky="w", padx=17, pady=(16, 5))
        ctk.CTkLabel(card, text=value, text_color=color, font=ctk.CTkFont(size=24, weight="bold")).grid(row=1, column=0, sticky="w", padx=17, pady=(0, 16))
        return card

    def page_overview(self):
        self.header("Обзор", "Краткая сводка по всем операциям")
        rows = self.db.all()
        income, expense, profit, vat = self.summary(rows)
        cards = ctk.CTkFrame(self.main, fg_color="transparent")
        cards.grid(row=2, column=0, sticky="ew")
        for i in range(4): cards.grid_columnconfigure(i, weight=1)
        values = [("Доходы", money(income), "#19A974"), ("Расходы", money(expense), "#E05D5D"),
                  ("Результат", money(profit), self.accent), ("НДС по ставкам", money(vat), "#D69E2E")]
        for i, (title, val, col) in enumerate(values):
            self.stat_card(cards, title, val, col).grid(row=0, column=i, padx=(0 if i == 0 else 10, 0), sticky="ew")
        ctk.CTkLabel(self.main, text="Последние операции", font=ctk.CTkFont(size=18, weight="bold")).grid(row=3, column=0, sticky="w", pady=(28, 12))
        self.table(self.main, rows[:8], row=4)

    def table(self, parent, rows, row=0):
        wrap = ctk.CTkFrame(parent, corner_radius=12)
        wrap.grid(row=row, column=0, sticky="nsew")
        wrap.grid_columnconfigure(0, weight=1)
        headers = ["Дата", "Тип", "Категория", "Описание", "Сумма", "НДС"]
        for col, h in enumerate(headers):
            ctk.CTkLabel(wrap, text=h, font=ctk.CTkFont(size=11, weight="bold"),
                         text_color=("gray45", "gray60")).grid(row=0, column=col, padx=10, pady=11, sticky="w")
        for idx, r in enumerate(rows, start=1):
            vals = [r[1], r[2], r[3], (r[4] or "—")[:28], money(r[5]), f"{r[6]:g}%"]
            for col, val in enumerate(vals):
                ctk.CTkLabel(wrap, text=val, font=ctk.CTkFont(size=12)).grid(row=idx, column=col, padx=10, pady=8, sticky="w")
            ctk.CTkFrame(wrap, height=1, fg_color=("gray88", "#273143")).grid(row=idx+1, column=0, columnspan=6, sticky="ew")
        if not rows:
            ctk.CTkLabel(wrap, text="Пока нет операций. Добавьте первую запись в разделе «Операции».",
                         text_color=("gray45", "gray60")).grid(row=1, column=0, columnspan=6, padx=14, pady=24)

    def page_entries(self):
        self.header("Операции", "Добавляйте доходы и расходы — они попадут в сводку и отчёты")
        form = ctk.CTkFrame(self.main, corner_radius=14)
        form.grid(row=2, column=0, sticky="ew", pady=(0, 18))
        fields = ctk.CTkFrame(form, fg_color="transparent")
        fields.grid(row=0, column=0, padx=16, pady=16, sticky="ew")
        for i in range(3): fields.grid_columnconfigure(i, weight=1)
        self.date_var = tk.StringVar(value=date.today().isoformat())
        self.kind_var = tk.StringVar(value="Доход")
        self.category_var = tk.StringVar(value="Услуги")
        self.desc_var = tk.StringVar()
        self.amount_var = tk.StringVar()
        self.vat_var = tk.StringVar(value="0%")
        self.field(fields, "Дата (ГГГГ-ММ-ДД)", self.date_var, 0, 0)
        ctk.CTkLabel(fields, text="Тип операции").grid(row=0, column=1, sticky="w", padx=8)
        ctk.CTkOptionMenu(fields, values=["Доход", "Расход"], variable=self.kind_var, fg_color=self.accent,
                          button_color=self.accent).grid(row=1, column=1, padx=8, pady=(4, 12), sticky="ew")
        ctk.CTkLabel(fields, text="Категория").grid(row=0, column=2, sticky="w", padx=8)
        ctk.CTkOptionMenu(fields, values=["Продажи", "Услуги", "Зарплата", "Аренда", "Закупки", "Налоги", "Транспорт", "Прочее"],
                          variable=self.category_var, fg_color=self.accent, button_color=self.accent).grid(row=1, column=2, padx=8, pady=(4, 12), sticky="ew")
        self.field(fields, "Описание", self.desc_var, 2, 0)
        self.field(fields, "Сумма", self.amount_var, 2, 1)
        ctk.CTkLabel(fields, text="Ставка НДС").grid(row=2, column=2, sticky="w", padx=8)
        ctk.CTkOptionMenu(fields, values=["0%", "5%", "10%", "20%"], variable=self.vat_var,
                          fg_color=self.accent, button_color=self.accent).grid(row=3, column=2, padx=8, pady=(4, 12), sticky="ew")
        ctk.CTkButton(form, text="＋  Добавить операцию", fg_color=self.accent, height=40,
                      command=self.add_entry).grid(row=1, column=0, padx=24, pady=(0, 16), sticky="e")
        ctk.CTkLabel(self.main, text="Все операции", font=ctk.CTkFont(size=18, weight="bold")).grid(row=3, column=0, sticky="w", pady=(0, 10))
        self.table(self.main, self.db.all(), row=4)

    def field(self, parent, label, variable, row, col):
        ctk.CTkLabel(parent, text=label).grid(row=row, column=col, sticky="w", padx=8)
        ctk.CTkEntry(parent, textvariable=variable, height=36).grid(row=row+1, column=col, sticky="ew", padx=8, pady=(4, 12))

    def add_entry(self):
        try:
            datetime.strptime(self.date_var.get().strip(), "%Y-%m-%d")
            amount = float(self.amount_var.get().replace(" ", "").replace(",", "."))
            if amount <= 0: raise ValueError
            vat = float(self.vat_var.get().replace("%", ""))
            self.db.add(self.date_var.get().strip(), self.kind_var.get(), self.category_var.get(),
                        self.desc_var.get().strip(), amount, vat)
            self.amount_var.set(""); self.desc_var.set("")
            self.show_page("entries")
        except ValueError:
            messagebox.showerror("Проверьте данные", "Введите корректную дату в формате ГГГГ-ММ-ДД и сумму больше нуля.")

    def page_calculator(self):
        self.header("Бухгалтерский калькулятор", "Быстрые расчёты суммы, НДС и маржи")
        panel = ctk.CTkFrame(self.main, corner_radius=16)
        panel.grid(row=2, column=0, sticky="ew")
        panel.grid_columnconfigure((0, 1), weight=1)
        self.calc_amount = tk.StringVar(value="10000")
        self.calc_vat = tk.StringVar(value="20%")
        self.calc_mode = tk.StringVar(value="Начислить НДС")
        self.calc_result = ctk.CTkLabel(panel, text="Введите сумму и нажмите «Рассчитать»", font=ctk.CTkFont(size=18, weight="bold"),
                                        text_color=self.accent)
        ctk.CTkLabel(panel, text="Исходная сумма").grid(row=0, column=0, padx=20, pady=(24, 5), sticky="w")
        ctk.CTkEntry(panel, textvariable=self.calc_amount, height=40).grid(row=1, column=0, padx=20, sticky="ew")
        ctk.CTkLabel(panel, text="Ставка НДС").grid(row=0, column=1, padx=20, pady=(24, 5), sticky="w")
        ctk.CTkOptionMenu(panel, values=["0%", "5%", "10%", "20%"], variable=self.calc_vat,
                          fg_color=self.accent, button_color=self.accent).grid(row=1, column=1, padx=20, sticky="ew")
        ctk.CTkLabel(panel, text="Режим расчёта").grid(row=2, column=0, padx=20, pady=(18, 5), sticky="w")
        ctk.CTkOptionMenu(panel, values=["Начислить НДС", "Выделить НДС из суммы"], variable=self.calc_mode,
                          fg_color=self.accent, button_color=self.accent).grid(row=3, column=0, padx=20, sticky="ew")
        ctk.CTkButton(panel, text="Рассчитать", fg_color=self.accent, height=42, command=self.calculate).grid(row=3, column=1, padx=20, sticky="ew")
        self.calc_result.grid(row=4, column=0, columnspan=2, padx=20, pady=30, sticky="w")
        ctk.CTkLabel(self.main, text="Важно: используйте расчёт как вспомогательный инструмент; налоговые правила зависят от вашей юрисдикции.",
                     wraplength=760, text_color=("gray45", "gray60")).grid(row=3, column=0, sticky="w", pady=16)

    def calculate(self):
        try:
            amount = float(self.calc_amount.get().replace(" ", "").replace(",", "."))
            rate = float(self.calc_vat.get().replace("%", "")) / 100
            if amount < 0: raise ValueError
            if self.calc_mode.get() == "Начислить НДС":
                vat = amount * rate
                total = amount + vat
                result = f"НДС: {money(vat)}     Итог с НДС: {money(total)}"
            else:
                vat = amount - amount / (1 + rate) if rate else 0
                result = f"Сумма без НДС: {money(amount-vat)}     НДС внутри суммы: {money(vat)}"
            self.calc_result.configure(text=result)
        except ValueError:
            messagebox.showerror("Ошибка", "Введите корректную числовую сумму.")


    def simple_calc_page(self, title, subtitle, fields, calculate_callback, button_text="Рассчитать"):
        self.header(title, subtitle)
        panel = ctk.CTkFrame(self.main, corner_radius=16)
        panel.grid(row=2, column=0, sticky="ew")
        panel.grid_columnconfigure((0, 1), weight=1)
        self.calc_vars = {}
        for idx, field in enumerate(fields):
            key, label, default, kind, options = field
            row, col = divmod(idx, 2)
            ctk.CTkLabel(panel, text=label).grid(row=row*2, column=col, padx=20, pady=(18, 5), sticky="w")
            var = tk.StringVar(value=default)
            self.calc_vars[key] = var
            if kind == "choice":
                widget = ctk.CTkOptionMenu(panel, values=options, variable=var, fg_color=self.accent, button_color=self.accent)
            else:
                widget = ctk.CTkEntry(panel, textvariable=var, height=38, placeholder_text=label)
            widget.grid(row=row*2+1, column=col, padx=20, pady=(0, 12), sticky="ew")
        ctk.CTkButton(panel, text=button_text, fg_color=self.accent, height=42,
                      command=calculate_callback).grid(row=((len(fields)+1)//2)*2, column=0, padx=20, pady=18, sticky="ew")
        self.simple_result = ctk.CTkLabel(panel, text="Заполните данные и нажмите «Рассчитать»",
                                           font=ctk.CTkFont(size=16, weight="bold"), text_color=self.accent,
                                           wraplength=800, justify="left")
        self.simple_result.grid(row=((len(fields)+1)//2)*2, column=1, padx=20, pady=18, sticky="w")
        ctk.CTkLabel(self.main, text="Расчёт ориентировочный. Перед применением проверьте действующие правила и ограничения для вашего региона.",
                     text_color=("gray45", "gray60"), wraplength=800).grid(row=3, column=0, sticky="w", pady=16)

    def cv(self, key):
        return self.calc_vars[key].get().strip()

    def num(self, key):
        return float(self.cv(key).replace(" ", "").replace(",", "."))

    def show_calc_result(self, text):
        self.simple_result.configure(text=text)

    def page_usn(self):
        self.simple_calc_page("Расчёт налога УСН",
            "Упрощённый расчёт налога с учётом объекта налогообложения, периода и страховых взносов",
            [("type", "Тип налогоплательщика", "ИП с работниками", "choice", ["ИП с работниками", "ИП без работников", "ООО"]),
             ("object", "Объект налогообложения", "Доходы", "choice", ["Доходы", "Доходы минус расходы"]),
             ("period", "Расчётный период", "Год", "choice", ["Первый квартал", "Полугодие", "9 месяцев", "Год"]),
             ("income", "Доходы за период, ₽", "1000000", "entry", None),
             ("expenses", "Расходы за период, ₽", "300000", "entry", None),
             ("rate", "Ставка налога, %", "6", "entry", None),
             ("contrib", "Страховые взносы, ₽", "0", "entry", None)],
            self.calculate_usn)

    def calculate_usn(self):
        try:
            income, expenses, rate, contrib = self.num("income"), self.num("expenses"), self.num("rate"), self.num("contrib")
            if min(income, expenses, rate, contrib) < 0 or rate > 100: raise ValueError
            taxable = income if self.cv("object") == "Доходы" else max(0, income-expenses)
            tax = taxable*rate/100
            # Typical simplified reduction cap: 50% for employers/companies; potentially 100% for sole proprietors without staff.
            cap = 1.0 if self.cv("type") == "ИП без работников" else 0.5
            due = max(0, tax-min(contrib, tax*cap)) if self.cv("object") == "Доходы" else tax
            self.show_calc_result(f"Налог до уменьшения: {money(tax)} ₽\\nК уплате после учёта взносов: {money(due)} ₽\\nНалоговая база: {money(taxable)} ₽")
        except ValueError:
            messagebox.showerror("Ошибка", "Проверьте числовые значения и ставку от 0 до 100.")

    def page_sick(self):
        self.simple_calc_page("Калькулятор больничного листа",
            "Оценка пособия по временной нетрудоспособности",
            [("start", "Дата начала (ГГГГ-ММ-ДД)", date.today().isoformat(), "entry", None),
             ("end", "Дата окончания (ГГГГ-ММ-ДД)", date.today().isoformat(), "entry", None),
             ("income", "Заработок за расчётные 2 года, ₽", "1200000", "entry", None),
             ("experience", "Страховой стаж", "5", "choice", ["Менее 5 лет", "5–8 лет", "8 лет и более"])],
            self.calculate_sick)

    def calculate_sick(self):
        try:
            start = datetime.strptime(self.cv("start"), "%Y-%m-%d").date()
            end = datetime.strptime(self.cv("end"), "%Y-%m-%d").date()
            income = self.num("income")
            days = (end-start).days+1
            if days < 1 or income < 0: raise ValueError
            factor = {"Менее 5 лет": 0.6, "5–8 лет": 0.8, "8 лет и более": 1.0}[self.cv("experience")]
            avg = income/730
            benefit = avg*factor*days
            self.show_calc_result(f"Дней нетрудоспособности: {days}\\nСредний дневной заработок: {money(avg)} ₽\\nОриентировочное пособие: {money(benefit)} ₽")
        except ValueError:
            messagebox.showerror("Ошибка", "Проверьте даты в формате ГГГГ-ММ-ДД и заработок.")

    def page_maternity(self):
        self.simple_calc_page("Калькулятор декретных",
            "Ориентировочная оценка пособия по беременности и родам",
            [("income", "Заработок за расчётные 2 года, ₽", "1200000", "entry", None),
             ("days", "Длительность отпуска, дней", "140", "choice", ["140", "156", "194"]),
             ("excluded", "Исключаемые дни", "0", "entry", None),
             ("min_day", "Средний дневной заработок, если известен (необязательно)", "0", "entry", None)],
            self.calculate_maternity)

    def calculate_maternity(self):
        try:
            income, excluded = self.num("income"), self.num("excluded")
            days = int(self.cv("days"))
            known = self.num("min_day")
            denominator = 730-excluded
            if income < 0 or excluded < 0 or denominator <= 0 or known < 0: raise ValueError
            avg = known if known > 0 else income/denominator
            total = avg*days
            self.show_calc_result(f"Средний дневной заработок: {money(avg)} ₽\\nПериод отпуска: {days} дней\\nОриентировочное пособие: {money(total)} ₽")
        except ValueError:
            messagebox.showerror("Ошибка", "Проверьте сумму заработка и количество исключаемых дней.")

    def page_vacation(self):
        self.simple_calc_page("Калькулятор отпускных",
            "Оценка отпускных по среднему заработку и числу календарных дней отпуска",
            [("income", "Начисления за расчётный период, ₽", "1200000", "entry", None),
             ("months", "Полных месяцев в периоде", "12", "entry", None),
             ("days", "Дней отпуска", "14", "entry", None),
             ("excluded", "Неучитываемые дни (оценка)", "0", "entry", None)],
            self.calculate_vacation)

    def calculate_vacation(self):
        try:
            income, months, days, excluded = self.num("income"), self.num("months"), self.num("days"), self.num("excluded")
            if min(income, months, days, excluded) < 0 or months <= 0: raise ValueError
            calendar_days = max(1, months*29.3-excluded)
            avg = income/calendar_days
            total = avg*days
            self.show_calc_result(f"Средний дневной заработок: {money(avg)} ₽\\nДней отпуска: {days:g}\\nОриентировочные отпускные: {money(total)} ₽")
        except ValueError:
            messagebox.showerror("Ошибка", "Проверьте начисления, месяцы, дни отпуска и исключаемые дни.")

    def page_reports(self):
        self.header("Отчёты и выгрузка", "Экспортируйте операции для дальнейшей обработки")
        box = ctk.CTkFrame(self.main, corner_radius=16)
        box.grid(row=2, column=0, sticky="ew")
        ctk.CTkLabel(box, text="Период отчёта (оставьте пустым для всех операций)", font=ctk.CTkFont(size=15, weight="bold")).grid(row=0, column=0, columnspan=2, padx=22, pady=(22, 14), sticky="w")
        self.report_start = tk.StringVar()
        self.report_end = tk.StringVar()
        ctk.CTkLabel(box, text="Дата начала").grid(row=1, column=0, padx=22, sticky="w")
        ctk.CTkEntry(box, textvariable=self.report_start, placeholder_text="2026-01-01", height=38).grid(row=2, column=0, padx=22, pady=(5, 14), sticky="ew")
        ctk.CTkLabel(box, text="Дата окончания").grid(row=1, column=1, padx=22, sticky="w")
        ctk.CTkEntry(box, textvariable=self.report_end, placeholder_text="2026-12-31", height=38).grid(row=2, column=1, padx=22, pady=(5, 14), sticky="ew")
        box.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(box, text="Выгрузить CSV", fg_color=self.accent, height=42, command=lambda: self.export("csv")).grid(row=3, column=0, padx=22, pady=(4, 22), sticky="ew")
        ctk.CTkButton(box, text="Выгрузить Excel (.xlsx)", fg_color=self.accent, height=42, command=lambda: self.export("xlsx")).grid(row=3, column=1, padx=22, pady=(4, 22), sticky="ew")
        ctk.CTkLabel(self.main, text="В отчёт включаются дата, тип, категория, описание, сумма, ставка и сумма НДС.").grid(row=3, column=0, sticky="w", pady=18)

    def export(self, fmt):
        start, end = self.report_start.get().strip(), self.report_end.get().strip()
        try:
            if bool(start) != bool(end): raise ValueError
            if start:
                datetime.strptime(start, "%Y-%m-%d"); datetime.strptime(end, "%Y-%m-%d")
                if start > end: raise ValueError
            rows = self.db.all(start or None, end or None)
        except ValueError:
            messagebox.showerror("Период не задан корректно", "Укажите обе даты в формате ГГГГ-ММ-ДД или оставьте обе пустыми.")
            return
        if not rows:
            messagebox.showinfo("Нет данных", "За выбранный период операций нет.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv" if fmt == "csv" else ".xlsx",
                  filetypes=[("CSV", "*.csv")] if fmt == "csv" else [("Excel", "*.xlsx")],
                  initialfile=f"buh_report_{date.today().isoformat()}")
        if not path: return
        headers = ["ID", "Дата", "Тип", "Категория", "Описание", "Сумма", "Ставка НДС, %", "Сумма НДС"]
        data = [[r[0], r[1], r[2], r[3], r[4] or "", r[5], r[6], round(r[5]*r[6]/100, 2)] for r in rows]
        try:
            if fmt == "csv":
                with open(path, "w", newline="", encoding="utf-8-sig") as f:
                    writer = csv.writer(f, delimiter=";"); writer.writerow(headers); writer.writerows(data)
            else:
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill
                wb = Workbook(); ws = wb.active; ws.title = "Операции"
                ws.append(headers)
                for cell in ws[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill("solid", fgColor=self.accent.replace("#", "").upper())
                for row in data: ws.append(row)
                ws.freeze_panes = "A2"; ws.auto_filter.ref = ws.dimensions
                for col, width in zip("ABCDEFGH", [8, 14, 14, 18, 32, 16, 16, 16]): ws.column_dimensions[col].width = width
                ws2 = wb.create_sheet("Сводка")
                inc, exp, prof, vat = self.summary(rows)
                ws2.append(["Показатель", "Значение"])
                for item in [("Доходы", inc), ("Расходы", exp), ("Результат", prof), ("НДС по операциям", vat)]:
                    ws2.append(list(item))
                ws2.column_dimensions["A"].width = 28; ws2.column_dimensions["B"].width = 20
                wb.save(path)
            messagebox.showinfo("Готово", f"Отчёт сохранён:\n{path}")
        except ImportError:
            messagebox.showerror("Не хватает библиотеки", "Для Excel установите openpyxl: pip install openpyxl")
        except Exception as e:
            messagebox.showerror("Ошибка экспорта", str(e))

    def page_settings(self):
        self.header("Настройка дизайна", "Меняйте тему и акцентный цвет интерфейса")
        box = ctk.CTkFrame(self.main, corner_radius=16)
        box.grid(row=2, column=0, sticky="ew")
        ctk.CTkLabel(box, text="Режим оформления", font=ctk.CTkFont(size=15, weight="bold")).grid(row=0, column=0, padx=22, pady=(22, 8), sticky="w")
        self.mode_choice = tk.StringVar(value=self.settings.get("mode", "Dark"))
        ctk.CTkSegmentedButton(box, values=["Dark", "Light", "System"], variable=self.mode_choice,
                               selected_color=self.accent, command=self.change_mode).grid(row=1, column=0, padx=22, sticky="w")
        ctk.CTkLabel(box, text="Акцентный цвет", font=ctk.CTkFont(size=15, weight="bold")).grid(row=2, column=0, padx=22, pady=(26, 8), sticky="w")
        self.accent_choice = tk.StringVar(value=next((k for k,v in ACCENTS.items() if v == self.accent), "Синий"))
        ctk.CTkOptionMenu(box, values=list(ACCENTS.keys()), variable=self.accent_choice,
                          fg_color=self.accent, button_color=self.accent, command=self.change_accent).grid(row=3, column=0, padx=22, sticky="w")
        ctk.CTkLabel(box, text="Цвет влияет на навигацию и основные кнопки. Настройки сохраняются автоматически.",
                     text_color=("gray45", "gray60"), wraplength=600).grid(row=4, column=0, padx=22, pady=24, sticky="w")
        ctk.CTkButton(box, text="Применить и обновить интерфейс", fg_color=self.accent,
                      command=lambda: self.show_page("settings")).grid(row=5, column=0, padx=22, pady=(0, 22), sticky="w")

    def change_mode(self, value):
        self.settings["mode"] = value
        self.save_settings()
        ctk.set_appearance_mode(value)

    def change_accent(self, value):
        self.accent = ACCENTS[value]
        self.settings["accent"] = self.accent
        self.save_settings()

    def refresh(self):
        pass

if __name__ == "__main__":
    app = App()
    app.mainloop()
